﻿using System;
using System.Collections;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Text.RegularExpressions;

startover:

string host;
int port = 10001;
NetworkStream stream;

host = "skull";
// host = "skull";
//host = "192.168.1.255";
//host = "192.168.1.12";

/*
try
{
    Console.WriteLine("please enter the following - ip:port");
    string[] IpAndPort = Console.ReadLine().Split(':');
    host = IpAndPort[0];
    port = Int32.Parse(IpAndPort[1]);
}
catch
{ 
    goto startover;
}
*/




if (!IsAnIpv4(host))
{
    IPAddress[] ipAddresses = Dns.GetHostAddresses(host);
    host = ipAddresses[1].ToString();
    //Console.WriteLine(host);
}
try
{
    TcpClient client = new TcpClient(host, port);
    stream = client.GetStream();
}
catch
{
    Console.WriteLine("Server not found, try again [any key]");
    Console.ReadKey();
    goto startover;
}

//////////////////experimental/////////////////
Queue<string> msgQueue = new Queue<string>();
msgQueue.Enqueue("hello");
msgQueue.Enqueue("hello2");
msgQueue.Enqueue("hello3");

Thread th = new Thread(() => QueueManager(msgQueue));
th.Start();
//////////////////////////////////////////////


Thread thread = new Thread(writeToStream);
thread.Start();

while (true)
{
    // Wait a sec/2 - avoid memory run out.
    System.Threading.Thread.Sleep(300);

    // recieve
    if (stream.DataAvailable)
    {
        byte[] buffer = new byte[2048];
        int a = stream.Read(buffer, 0, buffer.Length);
        for (int i = 0; i < buffer.Length; i++)
        {
            if (buffer[i] < 32 || buffer[i] > 126)
            {
                buffer[i] = 0;
            }
        }
        string str = Encoding.UTF8.GetString(buffer);
        Console.WriteLine(str);
        stream.Flush();
    }
    //Thread thread = new Thread(writeToStream);
    //thread.Start();

}
void writeToStream()
{
    while (true)
    {
        string message = Console.ReadLine();
        if (message != null && message.Length > 0)
        {
            byte[] data = System.Text.Encoding.ASCII.GetBytes(message);
            stream.Write(data, 0, data.Length);
            stream.Flush(); //warning! might flush incoming data
        }

    }
    //thread.Start();
}

static bool IsAnIpv4(string ip)
{
    string pattern = @"^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$";
    return Regex.IsMatch(ip, pattern);
}

static void QueueManager(Queue<string> queue)
{
    while (true)
    {
        if (queue.Count > 0)
        {
            Console.WriteLine(queue.Dequeue());
        }
        Thread.Sleep(100); //dont choke da hardware
    }
}

