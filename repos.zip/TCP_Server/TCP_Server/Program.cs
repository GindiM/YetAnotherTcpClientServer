﻿using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;

// Create the listener
TcpListener listener = new TcpListener(IPAddress.Any, 10001);

// Start listening for connections
listener.Start();
TcpClient client = listener.AcceptTcpClient();
NetworkStream stream = client.GetStream();

IPEndPoint remoteEndPoint = client.Client.RemoteEndPoint as IPEndPoint;
IPAddress remoteIp = remoteEndPoint.Address;

Console.WriteLine(remoteIp.ToString() + " is connected");

while (true)
{

    // Wait a sec
    //  System.Threading.Thread.Sleep(1000);


    Thread t = new Thread(writeToStream);
    t.Start();



    // Read data from the client
    byte[] request = new byte[1024];
    int bytesRead = stream.Read(request, 0, request.Length);
    string requestString = Encoding.UTF8.GetString(request, 0, bytesRead);
    stream.Flush();


    Console.WriteLine("user " + remoteIp.ToString() + ": " + requestString);
    //Console.WriteLine(requestString);


    // Send a response to the client
    byte[] response = Encoding.UTF8.GetBytes("Server: you said \"" + requestString + "\"");
    stream.Write(response, 0, response.Length);
    stream.Flush();


}

void writeToStream()
{

    while (true)
    {
        NetworkStream stream = client.GetStream();
        string message = Console.ReadLine();
        if (message != null && message.Length > 0)
        {
            byte[] data = System.Text.Encoding.ASCII.GetBytes(message);
            stream.Write(data, 0, data.Length);
            stream.Flush(); //warning! might flush incoming data
        }


    }

}